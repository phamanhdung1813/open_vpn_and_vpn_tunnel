#flush and reset
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
#Allow RDP to az-ws, SSH to az-ls
iptables -t nat -A PREROUTING -p tcp --dport 3085 -j DNAT --to-destination 172.16.85.4:3389
iptables -t nat -A PREROUTING -p tcp --dport 4085 -j DNAT --to-destination 172.16.85.5:22
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
#Close Policies
iptables -P INPUT DROP
iptables -P FORWARD DROP
#Allow appropriate ports IN, OUT and FORWARD
iptables -A INPUT -p tcp -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p tcp --sport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 123 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
#iptables -A INPUT -j LOG --log-prefix "INPUT-DROP "
iptables -A FORWARD -p tcp -d 172.16.85.4 --dport 3389 -j ACCEPT
iptables -A FORWARD -p tcp -s 172.16.85.4 --sport 3389 -j ACCEPT
iptables -A FORWARD -p tcp -d 172.16.85.5 --dport 22 -j ACCEPT
iptables -A FORWARD -p tcp -s 172.16.85.5 --sport 22 -j ACCEPT

