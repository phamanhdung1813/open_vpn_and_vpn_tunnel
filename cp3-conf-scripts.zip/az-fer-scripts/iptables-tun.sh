#flush and reset
iptables -F
iptables -X
iptables -t nat -F
iptables -t nat -X
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
#Allow RDP to az-ws, SSH to az-ls through Tunnel
iptables -t nat -A PREROUTING -p tcp -d 192.168.255.1 --dport 3085 -j DNAT --to-destination 172.16.85.4:3389
iptables -t nat -A PREROUTING -p tcp -d 192.168.255.1 --dport 4085 -j DNAT --to-destination 172.16.85.5:22
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
#Close Policies
iptables -P INPUT DROP
iptables -P FORWARD DROP
#Allow appropriate ports IN, OUT and FORWARD
iptables -A INPUT -p tcp -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p tcp --sport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 53 -j ACCEPT
iptables -A INPUT -p udp --sport 123 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -p udp --dport 1194 -j ACCEPT
iptables -A FORWARD -p tcp  --dport 3389 -j ACCEPT
iptables -A FORWARD -p tcp  --sport 3389 -j ACCEPT
iptables -A FORWARD -p tcp  --dport 22 -j ACCEPT
iptables -A FORWARD -p tcp  --sport 22 -j ACCEPT
iptables -A FORWARD -p tcp -d 172.16.85.4 --dport 53 -j ACCEPT
iptables -A FORWARD -p tcp -s 172.16.85.4 --sport 53 -j ACCEPT
iptables -A FORWARD -p udp -d 172.16.85.4 --dport 53 -j ACCEPT
iptables -A FORWARD -p udp -s 172.16.85.4 --sport 53 -j ACCEPT
