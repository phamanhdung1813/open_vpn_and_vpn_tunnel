pkill openvpn
/usr/sbin/openvpn --config /etc/openvpn/client/client.conf &
sleep 10
/usr/sbin/ip route add 172.16.85.0/24 via 192.168.255.2

